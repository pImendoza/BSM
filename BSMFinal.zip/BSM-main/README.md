# BSM
A smaller design of Leetcode made using mainly Python
